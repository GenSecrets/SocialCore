package com.nicholasdoherty.socialcore;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.HashMap;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.logging.Logger;

import com.nicholasdoherty.socialcore.emotes.EmoteCommand;
import com.nicholasdoherty.socialcore.emotes.EmoteListener;
import com.nicholasdoherty.socialcore.emotes.Emotes;
import com.nicholasdoherty.socialcore.genders.GenderCommandHandler;
import com.nicholasdoherty.socialcore.genders.Genders;
import com.nicholasdoherty.socialcore.marriages.MarriageCommandHandler;
import com.nicholasdoherty.socialcore.marriages.Marriages;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;




public class SocialCore extends JavaPlugin {
	
	//logger
	public final Logger log = Logger.getLogger("Minecraft");
		
	//lang
	public SCLang lang;
	
	//save
	public SaveHandler save;
	
	//players
	public HashMap<String,SocialPlayer>socialPlayersCache;
	
	//genders
	public Genders genders;
	
	//marriages
	public Marriages marriages;
	public static SocialCore plugin;
	//emotes
	public Emotes emotes;
	public enum Gender {
		MALE,FEMALE,UNSPECIFIED;
	}
	
	@Override
	public void onEnable() {
		plugin = this;
		//helpers
		checkConfig();
		String directory = getDataFolder().toString();
		save = new SaveHandler(directory, this);
		
		//commands
		SCCommandHandler scCommandHandler = new SCCommandHandler(this);
		MarriageCommandHandler marriageCommandHandler = new MarriageCommandHandler(this);
		GenderCommandHandler genderCommandHandler = new GenderCommandHandler(this);
		getCommand("socialcore").setExecutor(scCommandHandler);
		getCommand("male").setExecutor(genderCommandHandler);
		getCommand("female").setExecutor(genderCommandHandler);
		getCommand("gender").setExecutor(genderCommandHandler);
		getCommand("marriage").setExecutor(marriageCommandHandler);
		getCommand("marriages").setExecutor(marriageCommandHandler);
		getCommand("engagements").setExecutor(marriageCommandHandler);
		getCommand("propose").setExecutor(marriageCommandHandler);
		getCommand("marry").setExecutor(marriageCommandHandler);
		getCommand("divorce").setExecutor(marriageCommandHandler);
		getCommand("divorces").setExecutor(marriageCommandHandler);
		getCommand("adivorce").setExecutor(marriageCommandHandler);
		getCommand("amarry").setExecutor(marriageCommandHandler);
		getCommand("share").setExecutor(marriageCommandHandler);
		getCommand("unengage").setExecutor(marriageCommandHandler);
		getCommand("aunengage").setExecutor(marriageCommandHandler);

		//langs
		lang = new SCLang(this);
		lang.loadConfig();
		
		//events
		getServer().getPluginManager().registerEvents(new SCListener(this), this);
		
		//players
		socialPlayersCache = new HashMap<String,SocialPlayer>();
		
		//genders
		genders = new Genders();
		
		//marriages
		marriages = new Marriages(this);

		//emotes
		emotes = new Emotes(this);
		new EmoteListener(this);
		new EmoteCommand(this);
	}
	@Override
	public void onDisable() {
		for(String p : SCListener.riding.keySet()) {
			Bukkit.getPlayer(p).leaveVehicle();
		}
		
	}
	
	private void checkConfig() {
		if (!this.getDataFolder().isDirectory()) {
			this.getDataFolder().mkdirs();
		}
		if (!new File(this.getDataFolder(), "config.yml").isFile()) {
			this.writeConfig();
		}
	}
	private void writeConfig() {
		if (this.writeDefaultFileFromJar(new File(this.getDataFolder(), "config.yml"), "config.yml", true)) {
			log.info("[SocialCore] Saved default config.");
		}
	}
	private boolean writeDefaultFileFromJar(File writeName, String jarPath, boolean backupOld) {
		try {
			File fileBackup = new File(this.getDataFolder(), "backup-" + writeName);
			File jarloc = new File(getClass().getProtectionDomain().getCodeSource().getLocation().toURI()).getCanonicalFile();
			if (jarloc.isFile()) {
				JarFile jar = new JarFile(jarloc);
				JarEntry entry = jar.getJarEntry(jarPath);
				if (entry != null && !entry.isDirectory()) {
					InputStream in = jar.getInputStream(entry);
					InputStreamReader isr = new InputStreamReader(in, "UTF8");
					if (writeName.isFile()) {
						if (backupOld) {
							if (fileBackup.isFile()) {
								fileBackup.delete();
							}
							writeName.renameTo(fileBackup);
						} else {
							writeName.delete();
						}
					}
					FileOutputStream out = new FileOutputStream(writeName);
					OutputStreamWriter osw = new OutputStreamWriter(out, "UTF8");
					char[] tempbytes = new char[512];
					int readbytes = isr.read(tempbytes, 0, 512);
					while (readbytes > -1) {
						osw.write(tempbytes, 0, readbytes);
						readbytes = isr.read(tempbytes, 0, 512);
					}
					osw.close();
					isr.close();
					
					return true;
				}
				jar.close();
			}
			return false;
		} catch (Exception ex) {
			log.warning("[SocialCore] Failed to write default config. Stack trace follows:");
			ex.printStackTrace();
			return false;
		}
	}

}
