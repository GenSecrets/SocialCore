package com.nicholasdoherty.socialcore.marriages;

import java.util.ArrayList;
import java.util.Calendar;

import com.nicholasdoherty.socialcore.marriages.Divorce;
import com.nicholasdoherty.socialcore.marriages.Engagement;
import com.nicholasdoherty.socialcore.marriages.Marriage;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import com.nicholasdoherty.socialcore.SocialCore;
import com.nicholasdoherty.socialcore.SocialPlayer;

public class MarriageCommandHandler implements CommandExecutor {
	
	private SocialCore sc;

	public MarriageCommandHandler(SocialCore sc) {
		this.sc = sc;
	}

	@SuppressWarnings("deprecation")
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		
		if (sender instanceof Player) {
			Player player = (Player)sender;
			if (cmd.getName().equalsIgnoreCase("marriage")) {//show all marriage commands
				if (player.hasPermission("sc.marriage")) {
					player.sendMessage(ChatColor.GOLD+"---------=Marriage Commands=---------");
					if (player.hasPermission("sc.marriage"))
						player.sendMessage(ChatColor.AQUA+"/marriage - view list of marriage commands");
					if (player.hasPermission("sc.view.marriages"))
						player.sendMessage(ChatColor.AQUA+"/marriages - view all marriages on the server");
					if (player.hasPermission("sc.view.engagements"))
						player.sendMessage(ChatColor.AQUA+"/engagements - view all engagements on the server");
					if (player.hasPermission("sc.propose")) {
						player.sendMessage(ChatColor.AQUA+"/propose <player name> - propose to another player");
						player.sendMessage(ChatColor.AQUA+"/propose accept - accept a proposal");
						player.sendMessage(ChatColor.AQUA+"/propose deny - deny a proposal");
					}
					if (player.hasPermission("sc.unengage"))
						player.sendMessage(ChatColor.AQUA + "/unengage - To unengage your partner");
					if (player.hasPermission("sc.priest"))
						player.sendMessage(ChatColor.AQUA+"/marry <player1> <player2> - marry two players");
					if (player.hasPermission("sc.view.divorces"))
						player.sendMessage(ChatColor.AQUA+"/engagements - view all divorces on the server");
					if (player.hasPermission("sc.fileDivorce")) {
						player.sendMessage(ChatColor.AQUA+"/divorce - divorce your spouse");
						player.sendMessage(ChatColor.AQUA+"/divorce cancel - cancel a pending divorce");
					}
					if (player.hasPermission("sc.lawyer"))
						player.sendMessage(ChatColor.AQUA+"/divorce <player1> <player2> - divorce two players");

				}
				else {
					player.sendMessage(ChatColor.RED+"You do not have permission to view marriage commands!");
				}
			}
			else if (cmd.getName().equalsIgnoreCase("marriages")) {//view all marriages in the db
				int page = 0;
				if (args.length == 1) {
					page = Integer.valueOf(args[0]);
				}
				int perPage = 5;
				int lowerbound = (page*perPage);
				int upperbound = lowerbound + 5;
				if (upperbound >= sc.save.getAllMarriageNames().size()) {
					upperbound = sc.save.getAllMarriageNames().size();
					if (upperbound < 0)
						upperbound = 0;
					if (lowerbound >= sc.save.getAllMarriageNames().size()) {
						lowerbound = upperbound-perPage;
						if (lowerbound < 0)
							lowerbound = 0;
					}
				}
				if (player.hasPermission("sc.view.marriages")) {
					player.sendMessage(ChatColor.GOLD+"These are the marriages on the server: (Page " + page+")");
					if (upperbound-lowerbound > 0) {
						for (String s : sc.save.getAllMarriageNames().subList(lowerbound,upperbound)) {
							Marriage m = sc.save.getMarriage(s);
							player.sendMessage(ChatColor.GREEN+m.getHusband().getPlayerName()+" to "+m.getWife().getPlayerName()+" on "+m.getDate()+" by "+m.getPriest());
						}
						if (sc.save.getAllMarriageNames().size()-1 > upperbound) {
							player.sendMessage(ChatColor.translateAlternateColorCodes('&',"&6Type &c/marriages "+page+1+"&6 to read the next page."));
						}else {
							player.sendMessage(ChatColor.GOLD + "No more marriages to show");
						}
					}else {
						player.sendMessage(ChatColor.GREEN + "None");
					}
				}
				else {
					player.sendMessage(ChatColor.RED+"You do not have permission to view a list of marriages!");
				}
			}
			else if (cmd.getName().equalsIgnoreCase("engagements")) {//view all marriages in the db
				if (player.hasPermission("sc.view.engagements")) {
					player.sendMessage(ChatColor.GOLD+"These are the engagements on the server:");
					for (String s : sc.save.getAllEngagements()) {
						Engagement e = sc.save.getEngagement(s);
						player.sendMessage(ChatColor.GREEN+e.getFHusband().getPlayerName()+" and "+e.getFWife().getPlayerName()+" on "+e.getDate());
					}
				}
				else {
					player.sendMessage(ChatColor.RED+"You do not have permission to view a list of engagements!");
				}
			}
			else if (cmd.getName().equalsIgnoreCase("propose")) {
				/*ItemStack is = new ItemStack(Material.BEDROCK);
				ItemMeta me = is.getItemMeta();
				me.setDisplayName(ChatColor.RED+"Bedrock");
				is.setItemMeta(me);
				for (int i =0;i<64;i++)
					player.getInventory().addItem(is);*/
				if (args.length > 0) {
					if (args[0].equalsIgnoreCase("accept")) {
						SocialPlayer proposeFrom = sc.save.getSocialPlayer(player.getName());
						if (sc.marriages.getStatus(proposeFrom) == Marriages.Status.ProposeFrom) {
							SocialPlayer proposeTo = sc.marriages.proposals.get(proposeFrom);
							Player p = Bukkit.getServer().getPlayer(proposeTo.getPlayerName());
							if (p!=null) {
								p.sendMessage(ChatColor.GREEN+proposeFrom.getPlayerName()+" has accepted your hand in marriage! Congratulations!");
							}
							player.sendMessage(ChatColor.GREEN+"You have accepted "+proposeTo.getPlayerName()+"'s hand in marriage! Congratulations!");
							sc.marriages.proposals.remove(proposeFrom);
							
							Engagement e = new Engagement(proposeTo,proposeFrom);
							String dateBuilder = getMonth()+" "+Calendar.getInstance().get(Calendar.DAY_OF_MONTH)+", "+Calendar.getInstance().get(Calendar.YEAR);
							e.setDate(dateBuilder);
							e.setTime(System.currentTimeMillis());
							
							proposeFrom.setEngaged(true);
							proposeFrom.setEngagedTo(proposeTo.getPlayerName());
							proposeTo.setEngaged(true);
							proposeTo.setEngagedTo(proposeFrom.getPlayerName());
							
							sc.save.saveEngagement(e);
							sc.save.saveSocialPlayer(proposeFrom);
							sc.save.saveSocialPlayer(proposeTo);
							
							out:
							for (ItemStack item : p.getInventory().getContents()) {
								if (item!=null) {
									for (MarriageGem gem : sc.lang.marriageGems) {
										if (gem.getBlockID() == item.getTypeId()) {
											if (item.getItemMeta()!=null) {
												if (item.getItemMeta().getDisplayName()!=null) {
													if (item.getItemMeta().getDisplayName().contains(gem.getName())) {
														ItemMeta meta = item.getItemMeta();
														ArrayList<String>l = new ArrayList<String>();
													    l.add(proposeTo.getPlayerName()+" + "+proposeFrom.getPlayerName()+" 4ever");//
													    l.add("Engaged on "+e.getDate());
													    meta.setLore(l);
														item.setItemMeta(meta);
														player.getInventory().addItem(item);
														p.updateInventory();
														player.updateInventory();
														break out;
													}
												}
											}
										}
									}
								}
							}
							
							for (Player pr : Bukkit.getServer().getOnlinePlayers()) {
								if (pr.hasPermission("sc.priest")) {
									pr.sendMessage(ChatColor.GREEN+proposeTo.getPlayerName()+" and "+proposeFrom.getPlayerName()+" have become engaged!");
								}
							}
							
						}
						else {
							player.sendMessage(ChatColor.RED+"You have not been proposed to!");
						}
					}
					else if (args[0].equalsIgnoreCase("deny")) {
						SocialPlayer proposeFrom = sc.save.getSocialPlayer(player.getName());
						if (sc.marriages.getStatus(proposeFrom) == Marriages.Status.ProposeFrom) {
							SocialPlayer proposeTo = sc.marriages.proposals.get(proposeFrom);
							Player p = Bukkit.getServer().getPlayer(proposeTo.getPlayerName());
							if (p != null)
								p.sendMessage(ChatColor.DARK_RED+proposeFrom.getPlayerName()+" has declined your hand in marriage! :(");
							player.sendMessage(ChatColor.DARK_RED+"You have declined "+proposeTo.getPlayerName()+"'s hand in marriage!");
							sc.marriages.proposals.remove(proposeFrom);
						}
						else {
							player.sendMessage(ChatColor.RED+"You have not been proposed to!");
						}
					}
					else {
						Player p = Bukkit.getServer().getPlayer(args[0]);
						if (p == null) {
							player.sendMessage(ChatColor.RED+"Could not find player '"+args[0]+"'. Are they online?");
							return true;
						}
						
						SocialPlayer proposeTo = sc.save.getSocialPlayer(player.getName());
						SocialPlayer proposeFrom = sc.save.getSocialPlayer(p.getName());
						
						switch (sc.marriages.getStatus(proposeTo)) {
							case Married :
								player.sendMessage(ChatColor.RED+"You are already married! This isn't a polygamy state!");
								return true;
							case Engaged :
								player.sendMessage(ChatColor.RED+"You are already engaged! This isn't a polygamy state!");
								return true;
							case ProposeTo :
								player.sendMessage(ChatColor.RED+"You have already proposed to someone! This isn't a polygamy state!");
								return true;
							case ProposeFrom :
								player.sendMessage(ChatColor.RED+"You have already been proposed to! Type /propose deny to crush your previous lover's heart!");
								return true;
							case Single :
								break;
							default : break;
						}
						
						switch (sc.marriages.getStatus(proposeFrom)) {
							case Married :
								player.sendMessage(ChatColor.RED+"That player is already married! This isn't a polygamy state!");
								return true;
							case Engaged :
								player.sendMessage(ChatColor.RED+"That player is already engaged! This isn't a polygamy state!");
								return true;
							case ProposeTo :
								player.sendMessage(ChatColor.RED+"That player has already proposed to someone! This isn't a polygamy state!");
								return true;
							case ProposeFrom :
								player.sendMessage(ChatColor.RED+"That player has already been proposed to! This isn't a polygamy state!");
								return true;
							case Single :
								break;
							default : break;
						}
						
						if (proposeTo.getGender() == SocialCore.Gender.UNSPECIFIED) {
							player.sendMessage(ChatColor.RED+"You must specify your gender before you can propose! Type /male or /female");
							return true;
						}
						if (proposeFrom.getGender() == SocialCore.Gender.UNSPECIFIED) {
							p.sendMessage(ChatColor.RED+"Someone has tried to propose to you, but you havn't specified your gender! Type /male or /female");
							player.sendMessage(ChatColor.RED+proposeFrom.getPlayerName()+" hasn't specified their gender yet!");
							return true;
						}
						
						if (proposeTo.getGender() == proposeFrom.getGender() && !player.hasPermission("sc.samesex")) {
							player.sendMessage(ChatColor.RED+"Sorry, you need permission to have a samesex marriage.");
							return true;
						}
						
						if (!player.hasPermission("sc.propose")) {
							player.sendMessage(ChatColor.RED+"You do not have permision to marry another player!");
							return true;
						}
						if (!p.hasPermission("sc.propose")) {
							player.sendMessage(ChatColor.RED+proposeFrom.getPlayerName()+" does not have permission to marry!");
							return true;
						}
						
						boolean okay = false;
						
						out:
						for (ItemStack item : player.getInventory().getContents()) {
							if (item!=null) {
								for (MarriageGem gem : sc.lang.marriageGems) {
									if (gem.getBlockID() == item.getTypeId()) {
										if (item.getItemMeta()!=null) {
											if (item.getItemMeta().getDisplayName()!=null) {
												if (item.getItemMeta().getDisplayName().contains(gem.getName())) {
													boolean used = false;
													if (item.getItemMeta().hasLore()) {
														if (item.getItemMeta().getLore().size() >0) {
															if (item.getItemMeta().getLore().get(0).contains("4ever"))
																used = true;
														}
													}
													if (!used) {
														okay = true;
														break out;
													}
												}
											}
										}
									}
								}
							}
						}
						if (!okay) {
							player.sendMessage(ChatColor.RED+"You must have a marriage gem in order to propose!");
							return true;
						}
						
						sc.marriages.proposals.put(proposeFrom, proposeTo);
						player.sendMessage(ChatColor.GREEN+"You have asked "+p.getName()+ " for their hand in marriage!");
						p.sendMessage(ChatColor.GREEN+player.getName()+" is asking for your hand in marriage! Type '/propose accept' to accept it, or '/propose deny' to crush their heart!");
						return true;
					}
				}
				else {
					player.sendMessage(ChatColor.RED+"Usage: /propose <player name> or /propose accept/deny (to accept or deny a proposal");
				}
			}
			else if (cmd.getName().equalsIgnoreCase("marry")) {
				if (player.hasPermission("sc.priest")) {
					if (args.length > 1) {
						Player p1 = Bukkit.getServer().getPlayer(args[0]);
						if (p1==null) {
							player.sendMessage(ChatColor.RED+"Player '"+args[0]+"' cannot be found. Are they online?");
							return true;
						}
						Player p2 = Bukkit.getServer().getPlayer(args[1]);
						if (p2 == null) {
							player.sendMessage(ChatColor.RED+"Player '"+args[1]+"' cannot be found. Are they online?");
							return true;
						}
						
						SocialPlayer player1 = sc.save.getSocialPlayer(args[0]);
						SocialPlayer player2 = sc.save.getSocialPlayer(args[1]);
						
						if (!player1.isEngaged()) {
							player.sendMessage(ChatColor.RED+player1.getPlayerName()+" is not engaged!");
							return true;
						}
						if (!player2.isEngaged()) {
							player.sendMessage(ChatColor.RED+player2.getPlayerName()+" is not engaged!");
							return true;
						}
						if (!player1.getEngagedTo().equalsIgnoreCase(player2.getPlayerName())) {
							player.sendMessage(ChatColor.RED+player1.getPlayerName()+" is not engaged to "+player2.getPlayerName());
							return true;
						}
						if (!player2.getEngagedTo().equalsIgnoreCase(player1.getPlayerName())) {
							player.sendMessage(ChatColor.RED+player2.getPlayerName()+" is not engaged to "+player1.getPlayerName());
							return true;
						}
						
						p1.sendMessage(ChatColor.GREEN+"Father "+player.getName()+" is beginning the ceremony...");
						if (player.getLocation().distance(p1.getLocation()) > sc.lang.priestDistance) {
							player.sendMessage(ChatColor.RED+"The priest is too far away from "+player1.getPlayerName()+"!");
							p1.sendMessage(ChatColor.RED+"The priest is too far away from "+player1.getPlayerName()+"!");
							p2.sendMessage(ChatColor.RED+"The priest is too far away from "+player1.getPlayerName()+"!");
							return true;
						}
						if (player.getLocation().distance(p2.getLocation()) > sc.lang.priestDistance) {
							player.sendMessage(ChatColor.RED+"The priest is too far away from "+player2.getPlayerName()+"!");
							p1.sendMessage(ChatColor.RED+"The priest is too far away from "+player2.getPlayerName()+"!");
							p2.sendMessage(ChatColor.RED+"The priest is too far away from "+player2.getPlayerName()+"!");
							return true;
						}
						if (p1.getLocation().distance(p2.getLocation()) > sc.lang.coupleDistance) {
							player.sendMessage(ChatColor.RED+player1.getPlayerName()+" is too far away from "+player2.getPlayerName()+"!");
							p1.sendMessage(ChatColor.RED+player1.getPlayerName()+" is too far away from "+player2.getPlayerName()+"!");
							p2.sendMessage(ChatColor.RED+player1.getPlayerName()+" is too far away from "+player2.getPlayerName()+"!");
							return true;
						}
						
						Engagement e = sc.save.getEngagement(player1,player2);
						Marriage m = new Marriage(e.getFHusband(),e.getFWife());
						m.setPriest(player.getName());
						String dateBuilder = getMonth()+" "+Calendar.getInstance().get(Calendar.DAY_OF_MONTH)+", "+Calendar.getInstance().get(Calendar.YEAR);
						m.setDate(dateBuilder);
						
						boolean okay = false;
						out:
						for (ItemStack item : p1.getInventory().getContents()) {
							if (item!=null) {
								for (MarriageGem gem : sc.lang.marriageGems) {
									if (gem.getBlockID() == item.getTypeId()) {
										if (item.getItemMeta()!=null) {
											if (item.getItemMeta().getDisplayName()!=null) {
												if (item.getItemMeta().getDisplayName().contains(gem.getName())) {
													okay = true;
													break out;
												}
											}
										}
									}
								}
							}
						}
						
						if (!okay) {
							player.sendMessage(ChatColor.RED+"Uh oh! "+player1.getPlayerName()+" has misplaced their marriage gem!");
							p1.sendMessage(ChatColor.RED+"Uh oh! "+player1.getPlayerName()+" has misplaced their marriage gem!");
							p2.sendMessage(ChatColor.RED+"Uh oh! "+player1.getPlayerName()+" has misplaced their marriage gem!");
							return true;
						}
						
						okay = false;
						out:
							for (ItemStack item : p2.getInventory().getContents()) {
								if (item!=null) {
									for (MarriageGem gem : sc.lang.marriageGems) {
										if (gem.getBlockID() == item.getTypeId()) {
											if (item.getItemMeta()!=null) {
												if (item.getItemMeta().getDisplayName()!=null) {
													if (item.getItemMeta().getDisplayName().contains(gem.getName())) {
														ItemMeta meta = item.getItemMeta();
														ArrayList<String>l = new ArrayList<String>();
													    l.add(player1.getPlayerName()+" + "+player2.getPlayerName()+" 4ever");//
													    l.add("Married on "+m.getDate()+" by "+m.getPriest());
													    meta.setLore(l);
														item.setItemMeta(meta);
														p2.updateInventory();
														okay = true;
														break out;
													}
												}
											}
										}
									}
								}
							}
						
						if (!okay) {
							player.sendMessage(ChatColor.RED+"Uh oh! "+player2.getPlayerName()+" has misplaced their marriage gem!");
							p1.sendMessage(ChatColor.RED+"Uh oh! "+player2.getPlayerName()+" has misplaced their marriage gem!");
							p2.sendMessage(ChatColor.RED+"Uh oh! "+player2.getPlayerName()+" has misplaced their marriage gem!");
							return true;
						}
						out:
							for (ItemStack item : p1.getInventory().getContents()) {
								if (item!=null) {
									for (MarriageGem gem : sc.lang.marriageGems) {
										if (gem.getBlockID() == item.getTypeId()) {
											if (item.getItemMeta()!=null) {
												if (item.getItemMeta().getDisplayName()!=null) {
													if (item.getItemMeta().getDisplayName().contains(gem.getName())) {
														ItemMeta meta = item.getItemMeta();
														ArrayList<String>l = new ArrayList<String>();
													    l.add(player1.getPlayerName()+" + "+player2.getPlayerName()+" 4ever");//
													    l.add("Married on "+m.getDate()+" by "+m.getPriest());
													    meta.setLore(l);
														item.setItemMeta(meta);
														p1.updateInventory();
														break out;
													}
												}
											}
										}
									}
								}
							}
						
						sc.save.removeEngagement(e);
						player1.setEngaged(false);
						player1.setEngagedTo("");
						player1.setMarried(true);
						player1.setMarriedTo(player2.getPlayerName());
						player2.setEngaged(false);
						player2.setEngagedTo("");
						player2.setMarried(true);
						player2.setMarriedTo(player1.getPlayerName());
						sc.save.saveSocialPlayer(player1);
						sc.save.saveSocialPlayer(player2);
						sc.save.saveMarriage(m);
						
						player.sendMessage(ChatColor.GREEN+"You have married "+player1.getPlayerName()+" and "+player2.getPlayerName()+"!");
						String toSendPlayer1 = "You have taken "+player2.getPlayerName()+" to be your loftly wedded wife. Happy ever after!";
						if (player2.getGender().equals(SocialCore.Gender.MALE)) {
							toSendPlayer1.replace("wife", "husband.");
						}
						String toSendPlayer2  ="You have taken "+player2.getPlayerName()+" to be your loftly wedded wife. Happy ever after!";
						if (player1.getGender().equals(SocialCore.Gender.MALE)) {
							toSendPlayer2.replace("wife", "husband");
						}
						p1.sendMessage(toSendPlayer1);
						p2.sendMessage(toSendPlayer2);
						for (Player p : Bukkit.getServer().getOnlinePlayers()) {
							p.sendMessage(ChatColor.YELLOW+"[SocialCore] Father "+player.getName()+" has married "+player1.getPlayerName()+" and "+player2.getPlayerName()+"! Wish them a happy ever after!");
						}
						
					}
					else {
						player.sendMessage(ChatColor.RED+"Usage: /marry <player1> <player2>");
					}
				}
				else {
					player.sendMessage(ChatColor.RED+"You do not have permission to marry players!");
				}
			}
			else if (cmd.getName().equalsIgnoreCase("divorces")) {
				if (player.hasPermission("sc.view.divorces")) {
					player.sendMessage(ChatColor.GOLD+"These are the divorces on the server:");
					for (String s : sc.save.getAllDivorces()) {
						Divorce d = sc.save.getDivorce(s);
						player.sendMessage(ChatColor.GREEN+d.getExhusband().getPlayerName()+" and "+d.getExwife().getPlayerName()+" filed on "+d.getDate());
					}
				}
				else {
					player.sendMessage(ChatColor.RED+"You do not have permission to view a list of divorces!");
				}
			}
			else if (cmd.getName().equalsIgnoreCase("divorce")) {
				if (args.length < 1) {
					if (player.hasPermission("sc.fileDivorce")) {
						SocialPlayer p1 = sc.save.getSocialPlayer(player.getName());
						if (!p1.isMarried()) {
							player.sendMessage(ChatColor.RED+"You are not married!");
							return true;
						}
						if (sc.marriages.getPendingDivorces().contains(p1.getPlayerName())) {
							
							for (String s : sc.save.getAllDivorces()) {
								Divorce d = sc.save.getDivorce(s);
								if (d.getFiledBy().equalsIgnoreCase(p1.getPlayerName())) {
									player.sendMessage(ChatColor.RED+"You have already filed for a divorce. Please be patient while a lawyer looks into your case. Type /divorce cancel to cancel the divorce");
									return true;
								}
								if (d.getExhusband().getPlayerName().equalsIgnoreCase(player.getName())) {
									player.sendMessage(ChatColor.RED+"Your spouse has already filed for a divorce. Please be patient while a lawyer looks into your case.");
									return true;
								}
								if (d.getExwife().getPlayerName().equalsIgnoreCase(player.getName())) {
									player.sendMessage(ChatColor.RED+"Your spouse has already filed for a divorce. Please be patient while a lawyer looks into your case.");
									return true;
								}
							}
							
							SocialPlayer p2 = sc.save.getSocialPlayer(p1.getMarriedTo());

							Divorce divorce = new Divorce(p1,p2);
							String dateBuilder = getMonth()+" "+Calendar.getInstance().get(Calendar.DAY_OF_MONTH)+", "+Calendar.getInstance().get(Calendar.YEAR);
							divorce.setDate(dateBuilder);
							divorce.setFiledBy(player.getName());
							sc.save.saveDivorce(divorce);
							
							
							sc.marriages.getPendingDivorces().remove(p1.getPlayerName());
							player.sendMessage(ChatColor.AQUA+"A divorce has been filed for you and "+p1.getMarriedTo()+". A lawyer must review your application. Type /divorce cancel to cancel.");
							
							Player pl = Bukkit.getServer().getPlayer(p1.getMarriedTo());
							if (pl!=null)
								pl.sendMessage(ChatColor.YELLOW+p1.getPlayerName()+" has filed for a divorce :(");
							
							for (Player p : Bukkit.getServer().getOnlinePlayers()) {
								if (p.hasPermission("sc.lawyer")) {
									p.sendMessage(ChatColor.GREEN+"Lawyer, "+p1.getPlayerName()+" has filed for a divorce against "+p1.getMarriedTo());
								}
							}
						}
						else {
							for (String s : sc.save.getAllDivorces()) {
								Divorce d = sc.save.getDivorce(s);
								if (d.getFiledBy().equalsIgnoreCase(p1.getPlayerName())) {
									player.sendMessage(ChatColor.RED+"You have already filed for a divorce. Please be patient while a lawyer looks into your case. Type /divorce cancel to cancel the divorce");
									return true;
								}
								if (d.getExhusband().getPlayerName().equalsIgnoreCase(player.getName())) {
									player.sendMessage(ChatColor.RED+"Your spouse has already filed for a divorce. Please be patient while a lawyer looks into your case.");
									return true;
								}
								if (d.getExwife().getPlayerName().equalsIgnoreCase(player.getName())) {
									player.sendMessage(ChatColor.RED+"Your spouse has already filed for a divorce. Please be patient while a lawyer looks into your case.");
									return true;
								}
							}
							
							player.sendMessage(ChatColor.GOLD+"Are you sure you wish to divorce "+p1.getMarriedTo()+"? Type /divorce again to confirm.");
							sc.marriages.getPendingDivorces().add(p1.getPlayerName());
						}
					}
					else
						player.sendMessage(ChatColor.RED+"You do not have permission to divorce!");
						
				}
				else if (args.length > 0 && args[0].equalsIgnoreCase("cancel")) {
					if (player.hasPermission("sc.fileDivorce")) {
						SocialPlayer p = sc.save.getSocialPlayer(player.getName());
						Divorce divorce = null;
						for (String s : sc.save.getAllDivorces()) {
							Divorce d = sc.save.getDivorce(s);
							if (d.getFiledBy().equalsIgnoreCase(player.getName())) {
								divorce = d;
								break;
							}
						}
						
						if (divorce == null) {
							player.sendMessage(ChatColor.RED+"You have not filed for a divorce!");
							return true;
						}
						
						sc.save.removeDivorce(divorce);
						player.sendMessage(ChatColor.GREEN+"Your filing has been removed from the queue. Hopefully you two can work things out.");
						
						Player pl = Bukkit.getServer().getPlayer(p.getMarriedTo());
						if (pl!=null)
							pl.sendMessage(ChatColor.YELLOW+"Your spouse has removed their request for a divorce. Hopefully you two can work things out.");
					}
					else
						player.sendMessage(ChatColor.RED+"You do not have permission to divorce!");
				}
				else if (args.length > 1) {
					if (player.hasPermission("sc.lawyer")) {
						SocialPlayer p1 = sc.save.getSocialPlayer(args[0]);
						SocialPlayer p2 = sc.save.getSocialPlayer(args[1]);
						if (!p1.isMarried()) {
							player.sendMessage(ChatColor.RED+args[0]+" is not married!");
							return true;
						}
						if (!p1.getMarriedTo().equalsIgnoreCase(args[1])) {
							player.sendMessage(ChatColor.RED+args[0]+" is not married to "+args[1]+"!");
							return true;
						}
						
						Divorce divorce = null;
						for (String s : sc.save.getAllDivorces()) {
							Divorce d = sc.save.getDivorce(s);
							if (d.getFiledBy().equalsIgnoreCase(p1.getPlayerName())) {
								divorce = d;
								break;
							}
						}
						if (divorce == null) {
							player.sendMessage(ChatColor.RED+"That divorce could not be found!");
							return true;
						}
						
						Player pl = Bukkit.getServer().getPlayer(divorce.getFiledBy());
						if (pl!=null)
							pl.sendMessage(ChatColor.AQUA+"Lawyer "+player.getName()+" is reviewing your request to divorce "+p1.getMarriedTo());
						
						
						Marriage marriage = sc.save.getMarriage(p1,p2);
						
						sc.save.removeMarriage(marriage);
						sc.save.removeDivorce(divorce);
						
						player.sendMessage(ChatColor.GREEN+p1.getPlayerName()+" and "+p2.getPlayerName()+" are now divorced!");
						
						Player pl1 = Bukkit.getServer().getPlayer(p1.getPlayerName());
						Player pl2 = Bukkit.getServer().getPlayer(p2.getPlayerName());
						
						if (pl1!=null)
							pl1.sendMessage(ChatColor.YELLOW+"You and "+p1.getMarriedTo()+" are now divorced. Better luck next time.");
						if (pl2!=null)
							pl2.sendMessage(ChatColor.YELLOW+"You and "+p2.getMarriedTo()+" are now divorced. Better luck next time.");
						
						p1.setMarried(false);
						p1.setMarriedTo("");
						p2.setMarried(false);
						p2.setMarriedTo("");
						
						sc.save.saveSocialPlayer(p1);
						sc.save.saveSocialPlayer(p2);
						
						for (Player p : Bukkit.getServer().getOnlinePlayers()) {
							p.sendMessage(ChatColor.YELLOW+"[SocialCore] "+p1.getPlayerName()+" and "+p2.getPlayerName()+" are now divorced :(");
						}
					}
					else {
						player.sendMessage(ChatColor.RED+"Only a lawyer can complete a divorce!");
					}
				}
			}
			else if (cmd.getName().equalsIgnoreCase("adivorce")) {
				if (player.hasPermission("sc.admin")) {
					if (args.length > 1) {
						
						SocialPlayer sp1 = sc.save.getSocialPlayer(args[0]);
						SocialPlayer sp2 = sc.save.getSocialPlayer(args[1]);
						sp1.setEngaged(false);
						sp1.setEngagedTo("");
						sp1.setMarried(false);
						sp1.setMarriedTo("");
						sp2.setEngaged(false);
						sp2.setEngagedTo("");
						sp2.setMarried(false);
						sp2.setMarriedTo("");
						
						sc.save.saveSocialPlayer(sp1);
						sc.save.saveSocialPlayer(sp2);
						
						Divorce divorce = sc.save.getDivorce(sp1, sp2);
						if (divorce == null) {
							player.sendMessage(ChatColor.RED+"This is not a valid divorce");
							return true;
						}
						sc.save.removeDivorce(divorce);
						
						Marriage marriage = sc.save.getMarriage(sp1, sp2);
						if (marriage == null) {
							player.sendMessage(ChatColor.RED+"This is not a valid marriage");
							return true;
						}
						sc.save.removeMarriage(marriage);
						
						player.sendMessage(ChatColor.GREEN+"Forced divorce.");
					}
					else {
						player.sendMessage(ChatColor.RED+"Usage: /adivorce <player1> <player2>");
					}
				}
				else {
					player.sendMessage(ChatColor.RED+"You do not have permission to force a divorce");
				}
			}
			else if (cmd.getName().equalsIgnoreCase("amarry")) {
				if (player.hasPermission("sc.admin")) {
					if (args.length > 1) {
						
						SocialPlayer sp1 = sc.save.getSocialPlayer(args[0]);
						SocialPlayer sp2 = sc.save.getSocialPlayer(args[1]);
						
						sp1.setEngaged(false);
						sp1.setEngagedTo("");
						sp1.setMarried(true);
						sp1.setMarriedTo(args[1]);
						sp2.setEngaged(false);
						sp2.setEngagedTo("");
						sp2.setMarried(true);
						sp2.setMarriedTo(args[0]);
						
						sc.save.saveSocialPlayer(sp1);
						sc.save.saveSocialPlayer(sp2);
						
						Marriage marriage = new Marriage(sp1,sp2);
						marriage.setPriest(player.getName());
						String dateBuilder = getMonth()+" "+Calendar.getInstance().get(Calendar.DAY_OF_MONTH)+", "+Calendar.getInstance().get(Calendar.YEAR);
						marriage.setDate(dateBuilder);
						
						sc.save.saveMarriage(marriage);
						
						player.sendMessage(ChatColor.GREEN+"Force marriage.");
					}
					else {
						player.sendMessage(ChatColor.RED+"Usage: /amarry <player1> <player2>");
					}
				}
				else {
					player.sendMessage(ChatColor.RED+"You do not have permission to force a marriage");
				}
			}else if(cmd.getName().equalsIgnoreCase("share")) {
				
				Player p1 = (Player) sender;
				SocialPlayer sp1 = sc.save.getSocialPlayer(p1.getName());


				Player p2 =Bukkit.getServer().getPlayer(sp1.getMarriedTo());
				
				if(!sp1.isMarried()) {
					player.sendMessage(ChatColor.RED+"You are not married!");
					return true;
				}
				if(p2 == null || !p2.isOnline()) {
					player.sendMessage(ChatColor.RED+"Your Significant Other is offline!");
					return true;
				}
				if(p2.getWorld().getName().equalsIgnoreCase(p1.getWorld().getName())&& p2.getLocation().distanceSquared(p1.getLocation()) <= 25) {
					p1.openInventory(p2.getInventory());
					p2.sendMessage(ChatColor.AQUA+p1.getName()+" is viewing your inventory!");
					p1.sendMessage(ChatColor.AQUA+p2.getName()+"'s inventory");

					if(p2.getOpenInventory() != null) {
						p2.closeInventory();
					}
				}else {
					player.sendMessage(ChatColor.RED+"Your Significant Other is too far away!");

				}
				

			}
			if (cmd.getName().equalsIgnoreCase("unengage")) {
				System.out.println("test");
				if (sender.hasPermission("sc.unengage")) {
					Player p1 = (Player) sender;
					Engagement engagement = null;
					for (String eName : sc.save.getAllEngagements()) {
						Engagement engagement1 = sc.save.getEngagement(eName);
						if (engagement1.getFHusband().getPlayerName().equalsIgnoreCase(p1.getName()))
							engagement = engagement1;
						if (engagement1.getFWife().getPlayerName().equalsIgnoreCase(p1.getName()))
							engagement = engagement1;
					}
					if (engagement == null) {
						sender.sendMessage(ChatColor.RED + "You are not engaged.");
						return true;
					}
					engagement.getFHusband().setEngaged(false);
					engagement.getFWife().setEngaged(false);
					sc.save.removeEngagement(engagement);
					Player hus = Bukkit.getPlayer(engagement.getFHusband().getPlayerName());
					Player wife = Bukkit.getPlayer(engagement.getFWife().getPlayerName());
					if (hus.isOnline())
						hus.sendMessage(ChatColor.BLUE + "You have been unengaged.");
					if (wife.isOnline())
						hus.sendMessage(ChatColor.BLUE + "You have been unengaged.");
					return true;
				} else {
					sender.sendMessage(ChatColor.RED + "You do not have permission to unengage.");
				}

			}
		}
		if (cmd.getName().equalsIgnoreCase("aunengage")) {
			if (sender.hasPermission("sc.admin")) {
				if (args.length != 1) {
					sender.sendMessage("Usage: /aunengage <player>");
					return true;
				}
				Player p1 = Bukkit.getPlayer(args[0]);
				if (p1 == null) {
					sender.sendMessage(ChatColor.RED + args[0] + " is not a valid player.");
					return true;
				}
				Engagement engagement = null;
				for (String eName : sc.save.getAllEngagements()) {
					Engagement engagement1 = sc.save.getEngagement(eName);
					if (engagement1.getFHusband().getPlayerName().equalsIgnoreCase(p1.getName()))
						engagement = engagement1;
					if (engagement1.getFWife().getPlayerName().equalsIgnoreCase(p1.getName()))
						engagement = engagement1;
				}
				if (engagement == null) {
					sender.sendMessage(ChatColor.RED + p1.getName() + " is not engaged.");
					return true;
				}
				engagement.getFHusband().setEngaged(false);
				engagement.getFWife().setEngaged(false);
				Player hus = Bukkit.getPlayer(engagement.getFHusband().getPlayerName());
				Player wife = Bukkit.getPlayer(engagement.getFWife().getPlayerName());
				if (hus.isOnline())
					hus.sendMessage(ChatColor.BLUE + "You have been unengaged.");
				if (wife.isOnline())
					hus.sendMessage(ChatColor.BLUE + "You have been unengaged.");
				sc.save.removeEngagement(engagement);
				sender.sendMessage(ChatColor.GREEN + "You have successfully unengaged " + engagement.getFHusband().getPlayerName() + " and " + engagement.getFWife().getPlayerName());
			} else {
				sender.sendMessage(ChatColor.RED+"You do not have permission to force unengage somebody.");
			}
		}

		return true;
	}
	
	private String getMonth() {
		switch (Calendar.getInstance().get(Calendar.MONTH)) {
		case 0 : return "January";
		case 1 : return "February";
		case 2: return "March";
		case 3 : return "April";
		case 4 : return "May";
		case 5 : return "June";
		case 6 : return "July";
		case 7 : return "August";
		case 8 : return "September";
		case 9 : return "October";
		case 10 : return "November";
		case 11 : return "December";
		default : return "ERROR";
		}
	}

}