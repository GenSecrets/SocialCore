package com.nicholasdoherty.socialcore;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.nicholasdoherty.socialcore.marriages.Divorce;
import com.nicholasdoherty.socialcore.marriages.Engagement;
import com.nicholasdoherty.socialcore.marriages.Marriage;

public class SaveHandler {
	
	String directory;
	SocialCore sc;
	
	public SaveHandler(String directory, SocialCore sc) {
		this.directory = directory;
		this.sc = sc;
		
		String playerFolder = "/players";
		File f = new File(this.directory+playerFolder);
		sc.log.info("Creating players directory: "+f.toString());
		if (!f.exists()) {
			if (!f.isDirectory()){
		        if (!f.mkdirs()) {
		        	sc.log.severe("Failed to create players directory");
		        }
		    }
		}
		String marriagesFolder = "/marriages";
		f = new File(this.directory+marriagesFolder);
		sc.log.info("Creating marriages directory: "+f.toString());
		if (!f.exists()) {
			if (!f.isDirectory()){
		        if (!f.mkdirs()) {
		        	sc.log.severe("Failed to create marriages directory");
		        }
		    }
		}
		String engagementsFolder = "/engagements";
		f = new File(this.directory+engagementsFolder);
		sc.log.info("Creating engagements directory: "+f.toString());
		if (!f.exists()) {
			if (!f.isDirectory()){
		        if (!f.mkdirs()) {
		        	sc.log.severe("Failed to create engagements directory");
		        }
		    }
		}
		String divorceFolder = "/divorces";
		f = new File(this.directory+divorceFolder);
		sc.log.info("Creating divorceFolder directory: "+f.toString());
		if (!f.exists()) {
			if (!f.isDirectory()){
		        if (!f.mkdirs()) {
		        	sc.log.severe("Failed to create divorceFolder directory");
		        }
		    }
		}
	}
	
	public SocialCore.Gender getGenderForPlayer(String playerName) {
		
		return SocialCore.Gender.UNSPECIFIED;
	}
	
	public SocialPlayer getSocialPlayer(String playerName) {

		if (sc.socialPlayersCache.containsKey(playerName))
			return sc.socialPlayersCache.get(playerName);
		
		SocialPlayer sp = new SocialPlayer(playerName);
		JSONObject jsonObject = getJson(playerName,"players");
		if (jsonObject == null) {
			saveSocialPlayer (sp);
			return sp;
		}
		String g = (String)jsonObject.get("gender");
		g = g.toUpperCase();
		sp.setMarriedTo(""+jsonObject.get("marriedTo"));
		sp.setEngagedTo(""+jsonObject.get("engagedTo"));
		boolean isM = false;
		long i = (Long) jsonObject.get("isMarried");
		if (i==0)
			isM = true;
		sp.setMarried(isM);
		boolean isE = false;
		long e = (Long) jsonObject.get("isEngaged");
		if (e==0)
			isE = true;
		sp.setEngaged(isE);
		sp.setGender(SocialCore.Gender.valueOf(g));
		sc.socialPlayersCache.put(playerName, sp);
		return sp;
		
	}
	@SuppressWarnings("unchecked")
	public void saveSocialPlayer(SocialPlayer socialPlayer) {
		if (socialPlayer != null) {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("name", socialPlayer.getPlayerName());
			jsonObject.put("gender", socialPlayer.getGender().toString());
			jsonObject.put("marriedTo", socialPlayer.getMarriedTo());
			jsonObject.put("engagedTo", socialPlayer.getEngagedTo());
			long isM = 1;
			if (socialPlayer.isMarried())
				isM = 0;
			jsonObject.put("isMarried", isM);
			long isE = 1;
			if (socialPlayer.isEngaged())
				isE = 0;
			jsonObject.put("isEngaged", isE);
			sc.socialPlayersCache.put(socialPlayer.getPlayerName(), socialPlayer);
			saveJson(jsonObject,socialPlayer.getPlayerName(),"players");
		}
		else
			sc.log.severe("Cannot save a null player!");
	}
	
	public Marriage getMarriage(String marriageName) {
		
		Marriage marriage = new Marriage(marriageName, sc);
		return getMarriage(marriage.getHusband(), marriage.getWife());
	}
	
	public Marriage getMarriage(SocialPlayer husband, SocialPlayer wife) {
		
		String marriageName = husband.getPlayerName()+Marriage.NAME_DELIMITER+wife.getPlayerName();
		if (sc.marriages.marriagesCache.containsKey(marriageName)) {
			return sc.marriages.marriagesCache.get(marriageName);
		}
		
		Marriage marriage = new Marriage(husband,wife);
		
		JSONObject jsonObject = getJson(marriage.getName(),"marriages");
		if (jsonObject == null) {
			saveMarriage(marriage);
			return marriage;
		}
		
		marriage.setDate(""+jsonObject.get("date"));
		marriage.setPriest(""+jsonObject.get("priest"));
		
		sc.marriages.marriagesCache.put(marriageName, marriage);
		
		return marriage;
	}
	
	@SuppressWarnings("unchecked")
	public void saveMarriage(Marriage marriage) {
		
		if (marriage!=null) {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("husband",marriage.getHusband().getPlayerName());
			jsonObject.put("wife",marriage.getWife().getPlayerName());
			jsonObject.put("date", marriage.getDate());
			jsonObject.put("priest", marriage.getPriest());
			
			sc.marriages.marriagesCache.put(marriage.getName(), marriage);
			saveJson(jsonObject,marriage.getName(), "marriages");
		}
		else
			sc.log.severe("Cannot save a null player!");
		
	}
	
	public ArrayList<String> getAllMarriageNames() {
		ArrayList<String>names = new ArrayList<String>();
		File folder = new File(this.directory+"/marriages");
		
		for (File f : folder.listFiles()) {
			if (f.isFile()) {
				String data = f.getName().replaceAll(".json", "");
				names.add(data);
			}
		}
			
		return names;
	}
	public void removeMarriage(Marriage marriage) {
		File folder = new File(this.directory+"/marriages");
		
		for (File f : folder.listFiles()) {
			if (f.isFile()) {
				String data = f.getName().replaceAll(".json", "");
				if (data.equalsIgnoreCase(marriage.getName())) {
					f.delete();
					sc.marriages.marriagesCache.remove(marriage.getName());
					return;
				}
			}
		}
	}
	
	public Engagement getEngagement(String engagementName) {
		Engagement engagement = new Engagement(engagementName,sc);
		return getEngagement(engagement.getFHusband(), engagement.getFWife());
	}
	
	public Engagement getEngagement (SocialPlayer fHusband, SocialPlayer fWife) {
		String engagementName = fHusband.getPlayerName()+Engagement.NAME_DELIMITER+fWife.getPlayerName();
		if (sc.marriages.engagementsCache.containsKey(engagementName))
			return sc.marriages.engagementsCache.get(engagementName);
		
		Engagement engagement = new Engagement(fHusband, fWife);
		
		JSONObject jsonObject = getJson(engagement.getName(), "engagements");
		if (jsonObject == null) {
			engagement = new Engagement(fWife, fHusband);
			jsonObject = getJson(engagement.getName(), "engagements");
			if (jsonObject == null) {
				engagement = new Engagement(fHusband, fWife);
				saveEngagement(engagement);
				return engagement;
			}
		}
		
		engagement.setDate(""+jsonObject.get("date"));
		engagement.setTime((Long) jsonObject.get("time"));
		
		sc.marriages.engagementsCache.put(engagementName, engagement);
		
		return engagement;
	}
	
	@SuppressWarnings("unchecked")
	public void saveEngagement(Engagement engagement) {
		if (engagement != null) {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("fHusband", engagement.getFHusband().getPlayerName());
			jsonObject.put("fWife", engagement.getFWife().getPlayerName());
			jsonObject.put("date", engagement.getDate());
			jsonObject.put("time", engagement.getTime());
			
			sc.marriages.engagementsCache.put(engagement.getName(), engagement);
			saveJson(jsonObject,engagement.getName(),"engagements");
		}
		else
			sc.log.severe("Cannot save a null engagement!");
	}
	
	public void removeEngagement(Engagement engagement) {
		File folder = new File(this.directory+"/engagements");
		
		for (File f : folder.listFiles()) {
			if (f.isFile()) {
				String data = f.getName().replaceAll(".json", "");
				if (data.equalsIgnoreCase(engagement.getName())) {
					f.delete();
					sc.marriages.engagementsCache.remove(engagement.getName());
					return;
				}
			}
		}
	}
	
	public ArrayList<String>getAllEngagements() {
		ArrayList<String>names = new ArrayList<String>();
		File folder = new File(this.directory+"/engagements");
		
		for (File f : folder.listFiles()) {
			if (f.isFile()) {
				String data = f.getName().replaceAll(".json", "");
				names.add(data);
			}
		}
		
		return names;
	}
	
	public Divorce getDivorce(String divorceName) {
		Divorce divorce = new Divorce(divorceName,sc);
		return getDivorce(divorce.getExhusband(),divorce.getExwife());
	}
	public Divorce getDivorce(SocialPlayer exHusband, SocialPlayer exWife) {
		String divorceName = exHusband.getPlayerName()+Engagement.NAME_DELIMITER+exHusband.getPlayerName();
		if (sc.marriages.divorcesCache.containsKey(divorceName))
			return sc.marriages.divorcesCache.get(divorceName);
		
		Divorce divorce = new Divorce (exHusband,exWife);
		
		JSONObject jsonObject = getJson(divorce.getName(),"divorces");
		if (jsonObject == null) {
			divorce = new Divorce(exWife, exHusband);
			jsonObject = getJson(divorce.getName(), "divorces");
			if (jsonObject == null) {
				divorce = new Divorce(exHusband, exWife);
				saveDivorce(divorce);
				return divorce;
			}
		}
		
		divorce.setDate(""+jsonObject.get("date"));
		divorce.setFiledBy(""+jsonObject.get("filedBy"));
		
		sc.marriages.divorcesCache.put(divorceName, divorce);
		
		return divorce;
	}
	@SuppressWarnings("unchecked")
	public void saveDivorce(Divorce divorce) {
		if (divorce != null) {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("exHusband", divorce.getExhusband().getPlayerName());
			jsonObject.put("exWife", divorce.getExwife().getPlayerName());
			jsonObject.put("date", divorce.getDate());
			jsonObject.put("filedBy", divorce.getFiledBy());
			
			sc.marriages.divorcesCache.put(divorce.getName(), divorce);
			saveJson(jsonObject,divorce.getName(),"divorces");
		}
		else
			sc.log.severe("Cannot save a null divorce!");
	}
	public void removeDivorce(Divorce divorce) {
		File folder = new File(this.directory+"/divorces");
		
		for (File f : folder.listFiles()) {
			if (f.isFile()) {
				String data = f.getName().replaceAll(".json", "");
				if (data.equalsIgnoreCase(divorce.getName())) {
					f.delete();
					sc.marriages.divorcesCache.remove(divorce.getName());
					return;
				}
			}
		}
	}
	public ArrayList<String>getAllDivorces() {
		ArrayList<String>names = new ArrayList<String>();
		File folder = new File(this.directory+"/divorces");
		
		for (File f : folder.listFiles()) {
			if (f.isFile()) {
				String data = f.getName().replaceAll(".json", "");
				names.add(data);
			}
		}
		
		return names;
	}
	
	private void saveJson(JSONObject jsonObject, String fileName, String type) {
		try {
			
			FileWriter file = new FileWriter((directory+"/"+type+"/" + fileName + ".json"));
			file.write(jsonObject.toJSONString());
			file.flush();
			file.close();
		}
		catch (FileNotFoundException e) {
			sc.log.severe("No file for player: "+fileName);
		}
		catch (IOException e) {
			sc.log.severe("An error occured while saving player: "+fileName);
		}
		catch (NullPointerException e) {
			
		}
	}
	
	private JSONObject getJson(String fileName, String type) {
		
		JSONParser parser = new JSONParser();
		
		try {
			
			Object obj = parser.parse((new FileReader((directory+"/"+type+"/" + fileName + ".json"))));
			JSONObject jsonObject = (JSONObject)obj;
			return jsonObject;
			
		}
		catch (FileNotFoundException e) {
			
		}
		catch (IOException e) {
			sc.log.severe("An error occured while loading player: "+fileName);
		}
		catch (ParseException e) {
			sc.log.severe("An error occured while parsing player: "+fileName);
		}
		
		return null;
	}
}
