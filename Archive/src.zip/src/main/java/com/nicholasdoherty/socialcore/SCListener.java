package com.nicholasdoherty.socialcore;


import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Effect;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.player.PlayerExpChangeEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.bukkit.util.Vector;

public class SCListener implements Listener {
	public static HashMap<String,String> riding = new HashMap<String,String>();
	SocialCore sc;
	
	public SCListener(SocialCore sc) {
		this.sc = sc;
	}
	@EventHandler
	public void onPlayerItemConsume(FoodLevelChangeEvent e) {
		if(!(e.getEntity() instanceof Player)) return;
		Player p1 =(Player) e.getEntity();
		int changeby = e.getFoodLevel() - p1.getFoodLevel();
		SocialPlayer sp = sc.save.getSocialPlayer(p1.getName());
		if(!sp.isMarried()) return;
		Player p2 = Bukkit.getPlayer(sp.getMarriedTo());
		if(p2 == null) {
			return;
		}
		if(p2.getWorld().getName().equalsIgnoreCase(p1.getWorld().getName())&&p1.getLocation().distance(p2.getLocation()) <= 5) {
			e.setCancelled(true);
			p1.setFoodLevel(p1.getFoodLevel() + (changeby)/2);
			p2.setFoodLevel(p2.getFoodLevel() + (changeby)/2);
			p1.sendMessage(ChatColor.AQUA+"You shared your food with "+p2.getName());

			p2.sendMessage(ChatColor.AQUA+ p1.getName()+ " shared their food with you");
		}
	}
	@EventHandler
	public void onExpChange(PlayerExpChangeEvent e) {
		
		double ran = Math.random();
		if (ran <= sc.lang.coupleXPPercent) {
			Player p = e.getPlayer();
			if (p == null)
				return;
			
			SocialPlayer sp = sc.save.getSocialPlayer(p.getName());
			if (sp.isMarried()) {
				Player p2 = Bukkit.getServer().getPlayer(sp.getMarriedTo());
				if (p2 == null)
					return;
				if(!p.getWorld().equals(p2.getWorld())) return;
				if (p.getLocation().distanceSquared(p2.getLocation()) > Math.pow(sc.lang.coupleXPDistance,2))
					return;
				
				p2.giveExp(e.getAmount());
			}
		}
	}
	@EventHandler
	public void playerSneakEvent(PlayerToggleSneakEvent e) {
		Player p = e.getPlayer();
		if (p == null)
			return;
		if(riding.containsKey(p.getName())) {
			riding.remove(p.getName());
			p.leaveVehicle();
		}
	}
	@EventHandler
	public void onPlayerQuit(PlayerQuitEvent event) {
		if(event.getPlayer().isInsideVehicle()) {
			event.getPlayer().leaveVehicle();
			if(riding.containsKey(event.getPlayer().getName())) {
				riding.remove(event.getPlayer().getName());
			}
		}
		if(event.getPlayer().getPassenger() != null) {
			event.getPlayer().getPassenger().leaveVehicle();
			if(riding.containsKey(event.getPlayer().getName())) {
				riding.remove(event.getPlayer().getName());
			}
		}
	}
	@EventHandler
	public void onPlayerInteract(PlayerInteractEntityEvent e) {
		if (!(e.getRightClicked() instanceof Player))
			return;
					
		Player p = e.getPlayer();
		if (p == null)
			return;
		
		Player p2  = (Player)e.getRightClicked();
		if (p2 == null)
			return;
		
		if (!p.isSneaking()) {
			if(riding.containsKey(p2.getName())) {
				return;
			}
			if(p.getItemInHand().getType() != Material.SADDLE)
				return;
			SocialPlayer player1 = sc.save.getSocialPlayer(p.getName());
			SocialPlayer player2 = sc.save.getSocialPlayer(p2.getName());
			
			if (player1.getMarriedTo().equalsIgnoreCase(player2.getPlayerName())) {
				p2.setPassenger(p);
				p2.sendMessage(ChatColor.AQUA+"You are giving "+p.getName()+" a piggy-back ride!.");
				p.sendMessage(ChatColor.AQUA+p2.getName()+" is giving you a piggy-back ride.");
				riding.put(p.getName(), p2.getName());
			}
			
			return;
		}
		
		if (p.getLocation().distanceSquared(p2.getLocation()) > 4)
			return;
		
		if (!sc.marriages.canPlayerKiss(p.getName()))
			return;
		
		SocialPlayer player1 = sc.save.getSocialPlayer(p.getName());
		SocialPlayer player2 = sc.save.getSocialPlayer(p2.getName());
		
		if (player1.getMarriedTo().equalsIgnoreCase(player2.getPlayerName())) {
			
			Vector v = p.getEyeLocation().toVector();
			Vector v2 = p2.getEyeLocation().toVector();
			Vector v3 = v.midpoint(v2);
			Location loc = v3.toLocation(p.getWorld());
			p.getWorld().playEffect(loc, Effect.SMOKE, 0);
			
			p.sendMessage(ChatColor.AQUA+"You have kissed "+p2.getName()+".");
			p2.sendMessage(ChatColor.AQUA+p.getName()+" kisses you.");
			if(p.getMaxHealth() != p.getHealth()) {
				p.setHealth(p.getHealth() + 1);
			}
			if(p2.getMaxHealth() != p2.getHealth()) {
				p2.setHealth(p2.getHealth() + 1);
			}

			sc.marriages.kissPlayer(p.getName());
		}
		
	}

}
